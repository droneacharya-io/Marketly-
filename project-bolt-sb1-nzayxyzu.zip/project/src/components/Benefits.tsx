import { Brain, Clock, UserCheck, Award } from 'lucide-react';
import BenefitCard from './BenefitCard';

const benefits = [
  {
    icon: Brain,
    title: 'Actionable Insights',
    description: 'Generate innovative customer solutions backed by AI and real-world practices.'
  },
  {
    icon: Clock,
    title: 'Time-Saving',
    description: 'Eliminate the hassle of manual research by automating data gathering and analysis.'
  },
  {
    icon: UserCheck,
    title: 'Personalized Recommendations',
    description: 'Tailored solutions for product marketing, service selling, and customer experience improvement.'
  },
  {
    icon: Award,
    title: 'Expert Guidance',
    description: 'Access case studies, testimonials, and statistics to validate Marketly\'s industry expertise.'
  }
];

export default function Benefits() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Why Choose Marketly?
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <BenefitCard key={index} {...benefit} />
          ))}
        </div>
      </div>
    </section>
  );
}