import { Play } from 'lucide-react';
import { useState } from 'react';
import VideoModal from './VideoModal';
import DoodleCard from './DoodleCard';

const doodles = [
  {
    title: "Pain Points",
    description: "Understand the challenges faced by B2B marketers",
    doodleUrl: "https://images.unsplash.com/photo-1543269664-56d93c1b41a6?auto=format&fit=crop&w=800&h=800",
  },
  {
    title: "Global Best Practices",
    description: "Learn how Marketly connects you with proven solutions",
    doodleUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&h=800",
  },
  {
    title: "Feature Overview",
    description: "See our AI-driven recommendations in action",
    doodleUrl: "https://images.unsplash.com/photo-1551836022-4c4c79ecde51?auto=format&fit=crop&w=800&h=800",
  }
];

export default function VideoSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-12">
            Why Marketly?
          </h2>
          
          <div className="relative rounded-2xl overflow-hidden shadow-xl">
            <img 
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=1200&h=675" 
              alt="Marketing team collaboration"
              className="w-full h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-blue-500/90 hover:bg-blue-500 text-white rounded-full p-4 transition transform hover:scale-110"
              >
                <Play className="w-12 h-12 fill-current" />
              </button>
            </div>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-8">
            {doodles.map((doodle, index) => (
              <DoodleCard key={index} {...doodle} />
            ))}
          </div>
        </div>
      </div>
      
      {isModalOpen && <VideoModal onClose={() => setIsModalOpen(false)} />}
    </section>
  );
}