import { BrainCircuit } from 'lucide-react';

export default function Hero() {
  return (
    <section className="min-h-screen pt-32 pb-20 gradient-bg relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10">
        <img
          src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?auto=format&fit=crop&w=2000&q=80"
          alt="Team of Indian professionals"
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <BrainCircuit className="h-16 w-16 text-primary-100" />
            <h1 className="text-7xl md:text-8xl font-bold text-primary-50 ml-4">
              Marketly
            </h1>
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold text-primary-50 mb-6">
            Your AI-Powered B2B Marketing Innovation Partner
          </h2>
          
          <p className="text-xl text-primary-100 mb-10">
            Empowering Marketers with Industry-Specific Insights and Personalized Solutions
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="bg-primary-200 text-primary-50 px-8 py-3 rounded-full text-lg font-semibold hover:bg-primary-300 transition shadow-lg hover:shadow-xl">
              Start Free Trial
            </button>
            <button className="bg-transparent text-primary-50 px-8 py-3 rounded-full text-lg font-semibold border-2 border-primary-100 hover:bg-primary-400/50 transition shadow-lg hover:shadow-xl">
              Request a Demo
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}