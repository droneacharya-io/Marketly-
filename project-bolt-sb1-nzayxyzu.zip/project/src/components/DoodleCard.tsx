interface DoodleCardProps {
  title: string;
  description: string;
  doodleUrl: string;
}

export default function DoodleCard({ title, description, doodleUrl }: DoodleCardProps) {
  return (
    <div className="p-6 rounded-xl bg-gray-800/50 backdrop-blur-sm hover:bg-gray-800/70 transition group">
      <div className="relative overflow-hidden rounded-lg mb-4">
        <img 
          src={doodleUrl} 
          alt={title}
          className="w-full h-48 object-cover transform transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent" />
      </div>
      <h3 className="text-xl font-semibold text-blue-400 mb-2 text-center">
        {title}
      </h3>
      <p className="text-gray-300 text-center">
        {description}
      </p>
    </div>
  );
}