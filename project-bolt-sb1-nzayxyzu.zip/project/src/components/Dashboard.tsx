import { useSupabaseContext } from '../contexts/SupabaseContext';
import Header from './Header';
import Hero from './Hero';
import Benefits from './Benefits';
import VideoSection from './VideoSection';
import HowItWorks from './HowItWorks';
import Testimonials from './Testimonials';
import FAQ from './FAQ';
import Footer from './Footer';

export default function Dashboard() {
  const { user } = useSupabaseContext();

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />
      <main>
        <Hero />
        <Benefits />
        <VideoSection />
        <HowItWorks />
        <Testimonials />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}