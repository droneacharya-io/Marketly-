interface TestimonialCardProps {
  quote: string;
  author: string;
  image: string;
}

export default function TestimonialCard({ quote, author, image }: TestimonialCardProps) {
  return (
    <div className="bg-white p-8 rounded-xl shadow-lg">
      <div className="flex items-center space-x-4 mb-6">
        <img
          src={image}
          alt={author}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div>
          <p className="text-gray-600">{author}</p>
        </div>
      </div>
      <blockquote className="text-lg text-gray-700">
        "{quote}"
      </blockquote>
    </div>
  );
}