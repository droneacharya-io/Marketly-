import TestimonialCard from './TestimonialCard';

const testimonials = [
  {
    quote: "Marketly helped us boost customer engagement by 30% within a month!",
    author: "Marketing Lead, TechCorp",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=150&h=150"
  },
  {
    quote: "The insights Marketly provides are unmatched and time-saving.",
    author: "Head of Sales, MediCare Solutions",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150"
  },
  {
    quote: "Game-changing platform for our marketing strategy!",
    author: "CEO, InnovateTech",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150"
  },
  {
    quote: "The AI recommendations are spot-on every time.",
    author: "Marketing Director, GlobalSoft",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=150&h=150"
  }
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          What Our Users Say
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
}