import { BrainCircuit } from 'lucide-react';

export default function Logo() {
  return (
    <div className="flex items-center space-x-2">
      <BrainCircuit className="h-8 w-8 text-primary-100" />
      <span className="text-2xl font-bold text-primary-50">Marketly</span>
    </div>
  );
}