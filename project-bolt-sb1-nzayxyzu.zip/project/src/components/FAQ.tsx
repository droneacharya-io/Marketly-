import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useClickOutside } from '../hooks/useClickOutside';

const faqs = [
  {
    question: "How does Marketly ensure data privacy?",
    answer: "All data input is encrypted and stored securely, complying with global privacy standards. We use industry-leading encryption protocols and regular security audits to protect your valuable business data."
  },
  {
    question: "What industries does Marketly cater to?",
    answer: "Marketly supports a wide range of industries including healthcare, IT, manufacturing, finance, retail, and professional services. Our AI adapts to your specific industry context and requirements."
  },
  {
    question: "How long does it take to see results?",
    answer: "Most clients see meaningful insights and improvements within the first month of using Marketly. Our AI-powered platform provides immediate recommendations, while the full impact of implemented strategies typically shows within 3-6 months."
  },
  {
    question: "Can I integrate Marketly with my existing tools?",
    answer: "Yes, Marketly offers seamless integration with popular marketing and analytics tools. We support integration with CRM systems, analytics platforms, and marketing automation software."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const ref = useClickOutside<HTMLDivElement>(() => setOpenIndex(null));

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Common Questions
        </h2>
        <div className="max-w-3xl mx-auto" ref={ref}>
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="mb-4 bg-white rounded-lg shadow-sm overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <h3 className="text-lg font-semibold text-gray-900">
                  {faq.question}
                </h3>
                {openIndex === index ? (
                  <ChevronUp className="w-5 h-5 text-gray-500" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <p className="text-gray-600">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}