import { FileInput, Cpu, FileOutput } from 'lucide-react';
import StepCard from './StepCard';

const steps = [
  {
    icon: FileInput,
    title: 'Understand Your Needs',
    description: 'Share your goals and challenges through our intuitive interface.',
    image: 'https://images.unsplash.com/photo-1573497491765-dccce02b29df?auto=format&fit=crop&w=800&h=600'
  },
  {
    icon: Cpu,
    title: 'AI in Action',
    description: 'Our advanced AI processes your input using cutting-edge algorithms.',
    image: 'https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?auto=format&fit=crop&w=800&h=600'
  },
  {
    icon: FileOutput,
    title: 'Deliver Tailored Solutions',
    description: 'Receive comprehensive, actionable insights and recommendations.',
    image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&h=600'
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-white mb-12">
          How It Works
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <StepCard 
              key={index} 
              {...step} 
              isLast={index === steps.length - 1} 
            />
          ))}
        </div>
      </div>
    </section>
  );
}