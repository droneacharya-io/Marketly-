/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        neutral: {
          50: '#FAFAFA',
          100: '#F5F5F5',
          200: '#E5E5E5',
          300: '#D4D4D4',
          400: '#A3A3A3',
          500: '#737373',
          600: '#525252',
          700: '#404040',
          800: '#262626',
          900: '#171717',
        },
        accent: {
          50: '#F0F9FF',
          100: '#E0F2FE',
          200: '#BAE6FD',
          300: '#7DD3FC',
          400: '#38BDF8',
          500: '#0EA5E9',
          600: '#0284C7',
          700: '#0369A1',
          800: '#075985',
          900: '#0C4A6E',
        },
        sage: {
          50: '#F8FAF9',
          100: '#E8EFEB',
          200: '#D1DFD8',
          300: '#A3C1B2',
          400: '#75A38B',
          500: '#528569',
          600: '#3F6851',
          700: '#2F4D3C',
          800: '#1F3328',
          900: '#0F1A14',
        }
      },
      backgroundImage: {
        'gradient-minimal': 'linear-gradient(135deg, var(--tw-gradient-from) 0%, var(--tw-gradient-to) 100%)',
      },
      boxShadow: {
        'minimal': '0 2px 8px rgba(0, 0, 0, 0.05)',
        'minimal-lg': '0 4px 12px rgba(0, 0, 0, 0.08)',
        'minimal-xl': '0 8px 16px rgba(0, 0, 0, 0.12)',
      },
    },
  },
  plugins: [],
};